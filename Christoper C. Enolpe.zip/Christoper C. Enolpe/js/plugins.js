$(document).ready(function(){
	$('.intro_close').click(function(){
			$('.pop_box,.pop_box1').hide();
	});

	$('.modal_btn').click(function(e){
		e.preventDefault();
			$(this).parents('.bnr_box1').children('.pop_box').show();
	});

	$('.modal_link').click(function(event){
 	 event.preventDefault();
 		$('.pop_inner').hide();
 		$('.pop_box').show();

 		var id = $(this).attr("href");
 		$(id).show();
 	});

	$(window).bind('keydown', function(event) {
		if(event.keyCode === 27) {
			$('.pop_box').hide();
		}
	});

	$(function() {
		$('#select_law').change(function(){
				$('.options').hide();
				$('.pop_box1').show();

				$('#' + $(this).val()).show();
		});
	});

});
